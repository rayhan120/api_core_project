﻿namespace apicore.Repository
{
    public class CommonRepository
    {
    }
}