﻿using apicore.Models;
using EF.Core.Repository.Interface.Repository;

namespace apicore.Interfaces.Repository
{
    public interface IpostRepository:ICommonRepository<Post>
    {
    }
}
